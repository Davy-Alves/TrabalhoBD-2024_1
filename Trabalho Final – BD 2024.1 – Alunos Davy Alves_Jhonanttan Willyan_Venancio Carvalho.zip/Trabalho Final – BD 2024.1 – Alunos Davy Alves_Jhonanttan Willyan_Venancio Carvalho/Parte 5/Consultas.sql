-- 1.1. Em quais disciplinas está atualmente matriculado 
SET @matricula_aluno = 20230003;  -- <-Matricula do aluno 

SELECT d.Nome AS Disciplina 
FROM Disciplina_Cursada dc 
INNER JOIN Disciplina d ON dc.Disciplina = d.Codigo 
WHERE dc.Aluno = @matricula_aluno  
AND dc.Status = 'Cursando' 
GROUP BY d.Nome 
ORDER BY d.Nome; 

-- 1.2. quais disciplinas já concluiu 
SET @matricula_aluno = 20230001;  -- <-Matricula do aluno 

SELECT d.Nome AS Disciplina 
FROM Disciplina_Cursada dc 
INNER JOIN Disciplina d ON dc.Disciplina = d.Codigo 
WHERE dc.Aluno = @matricula_aluno 
AND dc.Status = 'Concluida' 
GROUP BY d.Nome 
ORDER BY d.Nome; 

-- 1.3. qual o curso deste aluno 
SET @matricula_aluno = 20230001;  -- <-Matricula do aluno 

SELECT  
    c.Nome AS Curso 
FROM  
    Aluno a 
INNER JOIN  
    Aluno_de_Graduacao ag ON a.Matricula = ag.Aluno_Matricula 
INNER JOIN  
    Curso c ON c.Cod = (SELECT Cod  
                       FROM Curso  
                       WHERE Cod = (SELECT DISTINCT di.Curso  
                                    FROM Disciplina di  
                                    INNER JOIN Disciplina_Cursada d ON di.Codigo = d.Disciplina 
                                    WHERE d.Aluno = a.Matricula 
                                    LIMIT 1)) 
WHERE  
    a.Matricula = @matricula_aluno 
GROUP BY  
    c.Nome 
ORDER BY  
    c.Nome; 

-- 1.4. dados pessoais sobre o aluno 
SET @matricula_aluno = 20230010;  -- <-Matricula do aluno 
SELECT  
    a.Nome, 
    a.Endereco, 
    t.Descricao AS Telefone_Descricao, 
    t.Numero AS Telefone_Numero 
FROM  
    Aluno a 
LEFT JOIN  
    Telefone t ON a.Matricula = t.Aluno_Matricula 
WHERE  
    a.Matricula = @matricula_aluno 
GROUP BY  
    a.Nome, 
    a.Endereco, 
    t.Descricao, 
    t.Numero 
ORDER BY  
    a.Nome; 


-- 2.1. cursos que estão sob a responsabilidade do departamento 
SET @departamento_codigo = 1;  -- <-Código do departamento 
SELECT  
    c.Cod AS Codigo_Curso, 
    c.Nome AS Nome_Curso 
FROM  
    Curso c 
WHERE  
    c.DEPARTAMENTO_cod = @departamento_codigo  
ORDER BY  
    c.Nome;   

-- 2.2. detalhes sobre o departamento 
SET @departamento_codigo = 1;  -- <-Código do departamento 
SELECT  
    d.cod AS Codigo_Departamento, 
    d.nome AS Nome_Departamento 
FROM  
    Departamento d 
WHERE  
    d.cod = @departamento_codigo; 

-- 3.1. disciplinas obrigatórias do curso 
SET @curso_codigo = 101;  -- <-Codigo do Curso 
SELECT 
    d.Codigo AS Codigo_Disciplina, 
    d.Nome AS Nome_Disciplina 
FROM  
    Disciplina d 
WHERE  
    d.Curso = @curso_codigo 
    AND d.Tipo = 'Obrigatória' 
ORDER BY  
    d.Nome;   

-- 3.2. disciplinas optativas do curso 
SET @curso_codigo = 101;  -- <-Codigo do Curso 
SELECT  
    d.Codigo AS Codigo_Disciplina, 
    d.Nome AS Nome_Disciplina 
FROM  
    Disciplina d 
WHERE  
    d.Curso = @curso_codigo 
    AND d.Tipo = 'Optativa' 
ORDER BY  
    d.Nome;   

-- 3.3. alunos desse curso 
SET @curso_codigo = 301;  -- <-Codigo do Curso 
SELECT  
    a.Matricula AS Matricula_Aluno, 
    a.Nome AS Nome_Aluno 
FROM  
    Aluno a 
JOIN  
    Disciplina_Cursada dc ON a.Matricula = dc.Aluno 
JOIN  
    Disciplina d ON dc.Disciplina = d.Codigo 
WHERE  
    d.Curso = @curso_codigo 
GROUP BY  
    a.Matricula, a.Nome   
ORDER BY  
    a.Nome;   

-- 3.4. alunos desse curso que já fizeram todas as disciplinas obrigatórias 
SET @curso_codigo = 201;  -- <-Codigo do Curso 

SET @total_disciplinas_obrigatorias = ( 
    SELECT COUNT(*) 
    FROM Disciplina d 
    WHERE d.Curso = @curso_codigo 
      AND d.Tipo = 'Obrigatória' 
); 

SELECT  
    a.Matricula AS Matricula_Aluno, 
    a.Nome AS Nome_Aluno 
FROM  
    Aluno a 
JOIN  
    Disciplina_Cursada dc ON a.Matricula = dc.Aluno 
JOIN  
    Disciplina d ON dc.Disciplina = d.Codigo 
WHERE  
    d.Curso = @curso_codigo 
    AND d.Tipo = 'Obrigatória' 
    AND dc.Status = 'Concluída' 
GROUP BY  
    a.Matricula, a.Nome 
HAVING  
    COUNT(DISTINCT d.Codigo) = @total_disciplinas_obrigatorias; 

-- 3.5. alunos desse curso que não fizeram nenhuma disciplina optativa 
SET @curso_codigo = 101;  -- <-Codigo do Curso 
SELECT  
    a.Matricula AS Matricula_Aluno, 
    a.Nome AS Nome_Aluno 
FROM  
    Aluno a 
LEFT JOIN  
    Disciplina_Cursada dc ON a.Matricula = dc.Aluno 
LEFT JOIN  
    Disciplina d ON dc.Disciplina = d.Codigo  
    AND d.Tipo = 'Optativa' 
WHERE  
    d.Curso = @curso_codigo 
GROUP BY  
    a.Matricula, a.Nome 
HAVING  
    SUM(CASE WHEN dc.Status = 'Concluída' THEN 1 ELSE 0 END) = 0; 

-- 4.1. alunos matriculados na disciplina 
SET @disciplina_codigo = '1006';  -- <-Codigo da Disciplina 

SELECT  
    a.Matricula AS Matricula_Aluno, 
    a.Nome AS Nome_Aluno 
FROM  
    Aluno a 
INNER JOIN  
    Disciplina_Cursada dc ON a.Matricula = dc.Aluno 
WHERE 
    dc.Disciplina = @disciplina_codigo 
GROUP BY  
    a.Matricula, a.Nome 
ORDER BY  
    a.Nome;   

-- 4.2. pré-requisitos da disciplina 
SET @disciplina_codigo = '1001';  -- <-Codigo da Disciplina 

SELECT  
    d2.Nome AS Nome_PreRequisito 
FROM  
    Pre_Requisitos pr 
INNER JOIN  
    Disciplina d1 ON pr.Disciplina = d1.Codigo 
INNER JOIN  
    Disciplina d2 ON pr.Pre_Requisito = d2.Codigo 
WHERE  
    d1.Codigo = @disciplina_codigo 
ORDER BY  
    d2.Nome;   

-- 4.3. disciplinas para as quais a mesma é pré-requisito 
SET @pre_requisito_codigo = '2006';  -- <-Codigo da Disciplina 

SELECT  
    d1.Nome AS Disciplina_Pre_Requisito, 
    d2.Nome AS Disciplina_Que_Depende 
FROM  
    Pre_Requisitos pr 
INNER JOIN  
    Disciplina d1 ON pr.Pre_Requisito = d1.Codigo 
INNER JOIN  
    Disciplina d2 ON pr.Disciplina = d2.Codigo 
WHERE  
    d1.Codigo = @pre_requisito_codigo 
ORDER BY  
    d2.Nome;   

-- 5.1. alunos orientandos daquele orientador 
SET @orientador_numero = 2001;  -- <-Numero do Orientador 

SELECT  
    a.Nome AS Nome_Aluno 
FROM  
    Aluno a 
INNER JOIN  
    Disciplina_Cursada dc ON a.Matricula = dc.Aluno 
INNER JOIN  
    Disciplina d ON dc.Disciplina = d.Codigo 
INNER JOIN  
    Orientador o ON d.Orientador = o.Numero 
WHERE 
    o.Numero = @orientador_numero 
ORDER BY  
    a.Nome;   

-- 5.2. disciplinas dadas pelo orientador 
SET @orientador_numero = 1002;  -- <-Numero do Orientador 

SELECT  
    d.Nome AS Nome_Disciplina 
FROM  
    Disciplina d 
INNER JOIN  
    Orientador o ON d.Orientador = o.Numero 
WHERE  
    o.Numero = @orientador_numero 
ORDER BY  
    d.Nome;  
 
-- 5.3. total de créditos das disciplinas do mesmo 
SET @orientador_numero = 1001;  -- Substitua 1001 pelo número do orientador desejado 

SELECT  
    SUM(d.Creditos) AS Total_Creditos 
FROM  
    Disciplina d 
INNER JOIN  
    Orientador o ON d.Orientador = o.Numero 
WHERE  
    o.Numero = @orientador_numero; 

 

 

 

 

 