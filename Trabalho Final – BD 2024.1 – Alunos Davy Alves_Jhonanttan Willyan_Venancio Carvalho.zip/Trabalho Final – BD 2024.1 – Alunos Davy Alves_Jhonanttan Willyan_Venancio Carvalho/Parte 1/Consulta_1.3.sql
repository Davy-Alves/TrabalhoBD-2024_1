-- 1.3. qual o curso deste aluno
SET @matricula_aluno = 20230001;  -- <-Matricula do aluno

SELECT 
    c.Nome AS Curso
FROM 
    Aluno a
INNER JOIN 
    Aluno_de_Graduacao ag ON a.Matricula = ag.Aluno_Matricula
INNER JOIN 
    Curso c ON c.Cod = (SELECT Cod 
                       FROM Curso 
                       WHERE Cod = (SELECT DISTINCT di.Curso 
                                    FROM Disciplina di 
                                    INNER JOIN Disciplina_Cursada d ON di.Codigo = d.Disciplina
                                    WHERE d.Aluno = a.Matricula
                                    LIMIT 1))
WHERE 
    a.Matricula = @matricula_aluno
GROUP BY 
    c.Nome
ORDER BY 
    c.Nome;