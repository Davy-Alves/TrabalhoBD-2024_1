-- 3.1. disciplinas obrigatórias do curso
SET @curso_codigo = 101;  -- <-Codigo do Curso

SELECT 
    d.Codigo AS Codigo_Disciplina,
    d.Nome AS Nome_Disciplina
FROM 
    Disciplina d
WHERE 
    d.Curso = @curso_codigo
    AND d.Tipo = 'Obrigatória'
ORDER BY 
    d.Nome;  
