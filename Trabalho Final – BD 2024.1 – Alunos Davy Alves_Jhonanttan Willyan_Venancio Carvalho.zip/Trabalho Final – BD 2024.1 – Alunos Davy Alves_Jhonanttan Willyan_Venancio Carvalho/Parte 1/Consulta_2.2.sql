-- 2.2. detalhes sobre o departamento
SET @departamento_codigo = 1;  -- <-Código do departamento

SELECT 
    d.cod AS Codigo_Departamento,
    d.nome AS Nome_Departamento
FROM 
    Departamento d
WHERE 
    d.cod = @departamento_codigo;
