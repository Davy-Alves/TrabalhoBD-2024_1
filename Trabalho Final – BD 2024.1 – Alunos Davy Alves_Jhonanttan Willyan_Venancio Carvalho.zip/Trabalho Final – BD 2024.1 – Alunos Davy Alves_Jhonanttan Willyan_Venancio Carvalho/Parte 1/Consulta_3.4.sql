-- 3.4. alunos desse curso que já fizeram todas as disciplinas obrigatórias
SET @curso_codigo = 201;  -- <-Codigo do Curso

SET @total_disciplinas_obrigatorias = (
    SELECT COUNT(*)
    FROM Disciplina d
    WHERE d.Curso = @curso_codigo
      AND d.Tipo = 'Obrigatória'
);

SELECT 
    a.Matricula AS Matricula_Aluno,
    a.Nome AS Nome_Aluno
FROM 
    Aluno a
JOIN 
    Disciplina_Cursada dc ON a.Matricula = dc.Aluno
JOIN 
    Disciplina d ON dc.Disciplina = d.Codigo
WHERE 
    d.Curso = @curso_codigo
    AND d.Tipo = 'Obrigatória'
    AND dc.Status = 'Concluída'
GROUP BY 
    a.Matricula, a.Nome
HAVING 
    COUNT(DISTINCT d.Codigo) = @total_disciplinas_obrigatorias;
