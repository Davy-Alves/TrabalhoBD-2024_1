-- 4.3. disciplinas para as quais a mesma é pré-requisito
SET @pre_requisito_codigo = '2006';  -- <-Codigo da Disciplina

SELECT 
    d1.Nome AS Disciplina_Pre_Requisito,
    d2.Nome AS Disciplina_Que_Depende
FROM 
    Pre_Requisitos pr
INNER JOIN 
    Disciplina d1 ON pr.Pre_Requisito = d1.Codigo
INNER JOIN 
    Disciplina d2 ON pr.Disciplina = d2.Codigo
WHERE 
    d1.Codigo = @pre_requisito_codigo
ORDER BY 
    d2.Nome;  
