-- 1.1. Em quais disciplinas está atualmente matriculado
SET @matricula_aluno = 20230003;  -- <-Matricula do aluno

SELECT d.Nome AS Disciplina
FROM Disciplina_Cursada dc
INNER JOIN Disciplina d ON dc.Disciplina = d.Codigo
WHERE dc.Aluno = @matricula_aluno 
AND dc.Status = 'Cursando'
GROUP BY d.Nome
ORDER BY d.Nome;