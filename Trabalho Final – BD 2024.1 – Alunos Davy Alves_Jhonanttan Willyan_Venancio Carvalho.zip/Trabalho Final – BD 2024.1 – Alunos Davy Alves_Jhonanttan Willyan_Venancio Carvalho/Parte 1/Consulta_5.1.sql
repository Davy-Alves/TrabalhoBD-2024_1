-- 5.1. alunos orientandos daquele orientador
SET @orientador_numero = 2001;  -- <-Numero do Orientador

SELECT 
    a.Nome AS Nome_Aluno
FROM 
    Aluno a
INNER JOIN 
    Disciplina_Cursada dc ON a.Matricula = dc.Aluno
INNER JOIN 
    Disciplina d ON dc.Disciplina = d.Codigo
INNER JOIN 
    Orientador o ON d.Orientador = o.Numero
WHERE 
    o.Numero = @orientador_numero
ORDER BY 
    a.Nome;  
