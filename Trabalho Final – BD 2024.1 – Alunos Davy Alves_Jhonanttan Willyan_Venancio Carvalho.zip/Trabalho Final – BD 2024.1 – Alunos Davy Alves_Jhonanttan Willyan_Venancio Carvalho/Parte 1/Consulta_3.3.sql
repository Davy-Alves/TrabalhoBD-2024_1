-- 3.3. alunos desse curso
SET @curso_codigo = 301;  -- <-Codigo do Curso

SELECT 
    a.Matricula AS Matricula_Aluno,
    a.Nome AS Nome_Aluno
FROM 
    Aluno a
JOIN 
    Disciplina_Cursada dc ON a.Matricula = dc.Aluno
JOIN 
    Disciplina d ON dc.Disciplina = d.Codigo
WHERE 
    d.Curso = @curso_codigo
GROUP BY 
    a.Matricula, a.Nome  
ORDER BY 
    a.Nome;  
