-- 1.4. dados pessoais sobre o aluno
SET @matricula_aluno = 20230010;  -- <-Matricula do aluno

SELECT 
    a.Nome,
    a.Endereco,
    t.Descricao AS Telefone_Descricao,
    t.Numero AS Telefone_Numero
FROM 
    Aluno a
LEFT JOIN 
    Telefone t ON a.Matricula = t.Aluno_Matricula
WHERE 
    a.Matricula = @matricula_aluno
GROUP BY 
    a.Nome,
    a.Endereco,
    t.Descricao,
    t.Numero
ORDER BY 
    a.Nome;