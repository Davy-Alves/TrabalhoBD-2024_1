-- 5.2. disciplinas dadas pelo orientador
SET @orientador_numero = 1002;  -- <-Numero do Orientador

SELECT 
    d.Nome AS Nome_Disciplina
FROM 
    Disciplina d
INNER JOIN 
    Orientador o ON d.Orientador = o.Numero
WHERE 
    o.Numero = @orientador_numero
ORDER BY 
    d.Nome; 

