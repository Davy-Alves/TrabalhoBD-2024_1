-- 1.2. quais disciplinas já concluiu
SET @matricula_aluno = 20230001;  -- <-Matricula do aluno

SELECT d.Nome AS Disciplina
FROM Disciplina_Cursada dc
INNER JOIN Disciplina d ON dc.Disciplina = d.Codigo
WHERE dc.Aluno = @matricula_aluno
AND dc.Status = 'Concluida'
GROUP BY d.Nome
ORDER BY d.Nome;
