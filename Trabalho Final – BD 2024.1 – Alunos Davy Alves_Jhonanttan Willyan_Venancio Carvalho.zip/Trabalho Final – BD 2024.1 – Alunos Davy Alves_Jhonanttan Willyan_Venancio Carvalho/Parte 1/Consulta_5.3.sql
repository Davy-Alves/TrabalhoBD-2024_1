-- 5.3. total de créditos das disciplinas do mesmo
SET @orientador_numero = 1001;  -- Substitua 1001 pelo número do orientador desejado

SELECT 
    SUM(d.Creditos) AS Total_Creditos
FROM 
    Disciplina d
INNER JOIN 
    Orientador o ON d.Orientador = o.Numero
WHERE 
    o.Numero = @orientador_numero;
