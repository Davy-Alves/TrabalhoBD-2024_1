-- 4.1. alunos matriculados na disciplina
SET @disciplina_codigo = '1006';  -- <-Codigo da Disciplina

SELECT 
    a.Matricula AS Matricula_Aluno,
    a.Nome AS Nome_Aluno
FROM 
    Aluno a
INNER JOIN 
    Disciplina_Cursada dc ON a.Matricula = dc.Aluno
WHERE 
    dc.Disciplina = @disciplina_codigo
GROUP BY 
    a.Matricula, a.Nome
ORDER BY 
    a.Nome;  
