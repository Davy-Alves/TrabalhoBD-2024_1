-- 2.1. cursos que estão sob a responsabilidade do departamento
SET @departamento_codigo = 1;  -- <-Código do departamento

SELECT 
    c.Cod AS Codigo_Curso,
    c.Nome AS Nome_Curso
FROM 
    Curso c
WHERE 
    c.DEPARTAMENTO_cod = @departamento_codigo 
ORDER BY 
    c.Nome;  
