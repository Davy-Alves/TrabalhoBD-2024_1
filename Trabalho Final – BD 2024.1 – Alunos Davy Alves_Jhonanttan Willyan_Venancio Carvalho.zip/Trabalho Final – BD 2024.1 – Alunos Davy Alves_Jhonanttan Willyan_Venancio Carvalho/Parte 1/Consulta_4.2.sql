-- 4.2. pré-requisitos da disciplina
SET @disciplina_codigo = '1001';  -- <-Codigo da Disciplina

SELECT 
    d2.Nome AS Nome_PreRequisito
FROM 
    Pre_Requisitos pr
INNER JOIN 
    Disciplina d1 ON pr.Disciplina = d1.Codigo
INNER JOIN 
    Disciplina d2 ON pr.Pre_Requisito = d2.Codigo
WHERE 
    d1.Codigo = @disciplina_codigo
ORDER BY 
    d2.Nome;  
