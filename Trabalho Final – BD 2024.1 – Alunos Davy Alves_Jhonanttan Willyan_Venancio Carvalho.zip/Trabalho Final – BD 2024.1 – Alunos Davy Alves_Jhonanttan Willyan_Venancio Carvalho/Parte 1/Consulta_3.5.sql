-- 3.5. alunos desse curso que não fizeram nenhuma disciplina optativa
SET @curso_codigo = 101;  -- <-Codigo do Curso

SELECT 
    a.Matricula AS Matricula_Aluno,
    a.Nome AS Nome_Aluno
FROM 
    Aluno a
LEFT JOIN 
    Disciplina_Cursada dc ON a.Matricula = dc.Aluno
LEFT JOIN 
    Disciplina d ON dc.Disciplina = d.Codigo 
    AND d.Tipo = 'Optativa'
WHERE 
    d.Curso = @curso_codigo
GROUP BY 
    a.Matricula, a.Nome
HAVING 
    SUM(CASE WHEN dc.Status = 'Concluída' THEN 1 ELSE 0 END) = 0;
