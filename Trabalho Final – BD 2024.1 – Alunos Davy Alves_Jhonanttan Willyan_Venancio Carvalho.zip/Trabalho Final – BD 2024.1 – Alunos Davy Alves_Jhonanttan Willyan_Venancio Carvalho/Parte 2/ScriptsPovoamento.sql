-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema Universidade
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema Universidade
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `Universidade` DEFAULT CHARACTER SET utf8 ;
USE `Universidade` ;

-- -----------------------------------------------------
-- Table `Universidade`.`DEPARTAMENTO`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Universidade`.`DEPARTAMENTO` ;

CREATE TABLE IF NOT EXISTS `Universidade`.`DEPARTAMENTO` (
  `cod` INT NOT NULL,
  `nome` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`cod`),
  UNIQUE INDEX `nome_UNIQUE` (`nome` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Universidade`.`Curso`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Universidade`.`Curso` ;

CREATE TABLE IF NOT EXISTS `Universidade`.`Curso` (
  `Cod` INT NOT NULL,
  `Nome` VARCHAR(45) NOT NULL,
  `Creditos` INT NULL DEFAULT 4,
  `DEPARTAMENTO_cod` INT NOT NULL,
  PRIMARY KEY (`Cod`, `DEPARTAMENTO_cod`),
  UNIQUE INDEX `Nome_UNIQUE` (`Nome` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Universidade`.`Orientador`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Universidade`.`Orientador` ;

CREATE TABLE IF NOT EXISTS `Universidade`.`Orientador` (
  `Numero` INT NOT NULL,
  `Nome` VARCHAR(45) NOT NULL,
  `DEPARTAMENTO` INT NOT NULL,
  PRIMARY KEY (`Numero`, `DEPARTAMENTO`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Universidade`.`Disciplina`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Universidade`.`Disciplina` ;

CREATE TABLE IF NOT EXISTS `Universidade`.`Disciplina` (
  `Codigo` INT NOT NULL,
  `Nome` VARCHAR(45) NOT NULL,
  `Ementa` VARCHAR(100) NULL,
  `Creditos` INT NOT NULL,
  `Tipo` VARCHAR(45) NULL,
  `Curso` INT NOT NULL,
  `DEPARTAMENTO` INT NOT NULL,
  `Orientador` INT NOT NULL,
  PRIMARY KEY (`Codigo`, `Curso`, `DEPARTAMENTO`),
  UNIQUE INDEX `Nome_UNIQUE` (`Nome` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Universidade`.`Aluno`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Universidade`.`Aluno` ;

CREATE TABLE IF NOT EXISTS `Universidade`.`Aluno` (
  `Matricula` VARCHAR(45) NOT NULL,
  `Nome` VARCHAR(45) NOT NULL,
  `Endereco` VARCHAR(45) NULL,
  PRIMARY KEY (`Matricula`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Universidade`.`Aluno_de_pos_graduacao`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Universidade`.`Aluno_de_pos_graduacao` ;

CREATE TABLE IF NOT EXISTS `Universidade`.`Aluno_de_pos_graduacao` (
  `Formacao` INT NOT NULL,
  `Orientador_Numero` INT NOT NULL,
  `Aluno_Matricula` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`Orientador_Numero`, `Aluno_Matricula`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Universidade`.`Aluno_de_Graduacao`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Universidade`.`Aluno_de_Graduacao` ;

CREATE TABLE IF NOT EXISTS `Universidade`.`Aluno_de_Graduacao` (
  `Ano_de_Ingresso` DATE NOT NULL,
  `Aluno_Matricula` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`Aluno_Matricula`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Universidade`.`Telefone`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Universidade`.`Telefone` ;

CREATE TABLE IF NOT EXISTS `Universidade`.`Telefone` (
  `Numero` INT NOT NULL,
  `Descricao` VARCHAR(45) NULL,
  `Aluno_Matricula` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`Numero`, `Aluno_Matricula`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Universidade`.`Disciplina_Cursada`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Universidade`.`Disciplina_Cursada` ;

CREATE TABLE IF NOT EXISTS `Universidade`.`Disciplina_Cursada` (
  `Aluno` VARCHAR(45) NOT NULL,
  `Disciplina` INT NOT NULL,
  `Media_Final` FLOAT NULL,
  `Frequenica` INT NULL,
  `Status` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`Aluno`, `Disciplina`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Universidade`.`Pre_Requisitos`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Universidade`.`Pre_Requisitos` ;

CREATE TABLE IF NOT EXISTS `Universidade`.`Pre_Requisitos` (
  `Disciplina` INT NOT NULL,
  `Pre_Requisito` INT NOT NULL,
  PRIMARY KEY (`Disciplina`, `Pre_Requisito`))
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

-- -----------------------------------------------------
-- Data for table `Universidade`.`DEPARTAMENTO`
-- -----------------------------------------------------
START TRANSACTION;
USE `Universidade`;
INSERT INTO `Universidade`.`DEPARTAMENTO` (`cod`, `nome`) VALUES (1, 'Ciência da Computação');
INSERT INTO `Universidade`.`DEPARTAMENTO` (`cod`, `nome`) VALUES (2, 'Saude Civil');

COMMIT;


-- -----------------------------------------------------
-- Data for table `Universidade`.`Curso`
-- -----------------------------------------------------
START TRANSACTION;
USE `Universidade`;
INSERT INTO `Universidade`.`Curso` (`Cod`, `Nome`, `Creditos`, `DEPARTAMENTO_cod`) VALUES (101, 'Engenharia da Computação', 8, 1);
INSERT INTO `Universidade`.`Curso` (`Cod`, `Nome`, `Creditos`, `DEPARTAMENTO_cod`) VALUES (201, 'Sistemas de Informação', 6, 1);
INSERT INTO `Universidade`.`Curso` (`Cod`, `Nome`, `Creditos`, `DEPARTAMENTO_cod`) VALUES (301, 'Medicina ', 6, 2);
INSERT INTO `Universidade`.`Curso` (`Cod`, `Nome`, `Creditos`, `DEPARTAMENTO_cod`) VALUES (401, 'Odontologia', 7, 2);

COMMIT;


-- -----------------------------------------------------
-- Data for table `Universidade`.`Orientador`
-- -----------------------------------------------------
START TRANSACTION;
USE `Universidade`;
INSERT INTO `Universidade`.`Orientador` (`Numero`, `Nome`, `DEPARTAMENTO`) VALUES (1001, 'Dr. João Silva', 1);
INSERT INTO `Universidade`.`Orientador` (`Numero`, `Nome`, `DEPARTAMENTO`) VALUES (1002, 'Dra. Maria Oliveira', 1);
INSERT INTO `Universidade`.`Orientador` (`Numero`, `Nome`, `DEPARTAMENTO`) VALUES (2001, 'Dr. Ana Costa', 2);
INSERT INTO `Universidade`.`Orientador` (`Numero`, `Nome`, `DEPARTAMENTO`) VALUES (2002, 'Dr. Carlos Pereira', 2);

COMMIT;


-- -----------------------------------------------------
-- Data for table `Universidade`.`Disciplina`
-- -----------------------------------------------------
START TRANSACTION;
USE `Universidade`;
INSERT INTO `Universidade`.`Disciplina` (`Codigo`, `Nome`, `Ementa`, `Creditos`, `Tipo`, `Curso`, `DEPARTAMENTO`, `Orientador`) VALUES (1001, 'Programação 1', 'Introdução à programação com ênfase em C e Python', 4, 'Obrigatória', 101, 1, 1001);
INSERT INTO `Universidade`.`Disciplina` (`Codigo`, `Nome`, `Ementa`, `Creditos`, `Tipo`, `Curso`, `DEPARTAMENTO`, `Orientador`) VALUES (1002, 'Cálculo 1', 'Cálculo diferencial e integral aplicado à computação', 4, 'Obrigatória', 101, 1, 1001);
INSERT INTO `Universidade`.`Disciplina` (`Codigo`, `Nome`, `Ementa`, `Creditos`, `Tipo`, `Curso`, `DEPARTAMENTO`, `Orientador`) VALUES (1003, 'Física para Engenharia', 'Mecânica clássica e eletromagnetismo com aplicações em circuitos', 5, 'Obrigatória', 101, 1, 1001);
INSERT INTO `Universidade`.`Disciplina` (`Codigo`, `Nome`, `Ementa`, `Creditos`, `Tipo`, `Curso`, `DEPARTAMENTO`, `Orientador`) VALUES (1004, 'Algoritmos e Estruturas de Dados', 'Estudo de algoritmos e suas implementações em diversas linguagens', 5, 'Optativa', 101, 1, 1002);
INSERT INTO `Universidade`.`Disciplina` (`Codigo`, `Nome`, `Ementa`, `Creditos`, `Tipo`, `Curso`, `DEPARTAMENTO`, `Orientador`) VALUES (1005, 'Álgebra Linear', 'Vetores, matrizes e suas aplicações na computação gráfica', 4, 'Obrigatória', 201, 1, 1002);
INSERT INTO `Universidade`.`Disciplina` (`Codigo`, `Nome`, `Ementa`, `Creditos`, `Tipo`, `Curso`, `DEPARTAMENTO`, `Orientador`) VALUES (1006, 'Sistemas Digitais', 'Introdução à lógica digital', 4, 'Obrigatória', 201, 1, 1002);
INSERT INTO `Universidade`.`Disciplina` (`Codigo`, `Nome`, `Ementa`, `Creditos`, `Tipo`, `Curso`, `DEPARTAMENTO`, `Orientador`) VALUES (1007, 'Sistemas Analogicos', 'Introdução à lógica digital, portas Analogica e circuitos', 4, 'Optativa', 201, 1, 1002);
INSERT INTO `Universidade`.`Disciplina` (`Codigo`, `Nome`, `Ementa`, `Creditos`, `Tipo`, `Curso`, `DEPARTAMENTO`, `Orientador`) VALUES (2001, 'Anatomia Humana', 'Estudo detalhado da estrutura do corpo humano', 5, 'Obrigatória', 301, 2, 2001);
INSERT INTO `Universidade`.`Disciplina` (`Codigo`, `Nome`, `Ementa`, `Creditos`, `Tipo`, `Curso`, `DEPARTAMENTO`, `Orientador`) VALUES (2002, 'Fisiologia Humana', 'Estudo detalhado da estrutura do corpo humano', 5, 'Obrigatória', 301, 2, 2001);
INSERT INTO `Universidade`.`Disciplina` (`Codigo`, `Nome`, `Ementa`, `Creditos`, `Tipo`, `Curso`, `DEPARTAMENTO`, `Orientador`) VALUES (2003, 'Bioquímica', 'Funções e mecanismos dos sistemas orgânicos humanos', 5, 'Optativa', 301, 2, 2001);
INSERT INTO `Universidade`.`Disciplina` (`Codigo`, `Nome`, `Ementa`, `Creditos`, `Tipo`, `Curso`, `DEPARTAMENTO`, `Orientador`) VALUES (2004, 'Histologia', 'Estudo das bases moleculares dos processos biológicos', 4, 'Obrigatória', 401, 2, 2001);
INSERT INTO `Universidade`.`Disciplina` (`Codigo`, `Nome`, `Ementa`, `Creditos`, `Tipo`, `Curso`, `DEPARTAMENTO`, `Orientador`) VALUES (2005, 'Farmacologia', 'Microscopia e estudo dos tecidos humanos', 4, 'Obrigatória', 401, 2, 2002);
INSERT INTO `Universidade`.`Disciplina` (`Codigo`, `Nome`, `Ementa`, `Creditos`, `Tipo`, `Curso`, `DEPARTAMENTO`, `Orientador`) VALUES (2006, 'Microbiologia', 'Estudo dos fármacos e suas interações com o organismo', 4, 'Obrigatória', 401, 2, 2002);
INSERT INTO `Universidade`.`Disciplina` (`Codigo`, `Nome`, `Ementa`, `Creditos`, `Tipo`, `Curso`, `DEPARTAMENTO`, `Orientador`) VALUES (2007, 'Patologia', 'Estudo dos micro-organismos e suas implicações na saúde', 4, 'Optativa', 401, 2, 2002);

COMMIT;


-- -----------------------------------------------------
-- Data for table `Universidade`.`Aluno`
-- -----------------------------------------------------
START TRANSACTION;
USE `Universidade`;
INSERT INTO `Universidade`.`Aluno` (`Matricula`, `Nome`, `Endereco`) VALUES ('20230001', 'Carlos Eduardo', 'Rua A, 123');
INSERT INTO `Universidade`.`Aluno` (`Matricula`, `Nome`, `Endereco`) VALUES ('20230002', 'Ana Beatriz', 'Rua B, 456');
INSERT INTO `Universidade`.`Aluno` (`Matricula`, `Nome`, `Endereco`) VALUES ('20230003', 'Pedro Henrique', 'Rua C, 789');
INSERT INTO `Universidade`.`Aluno` (`Matricula`, `Nome`, `Endereco`) VALUES ('20230004', 'Lucas Almeida', 'Rua D, 101');
INSERT INTO `Universidade`.`Aluno` (`Matricula`, `Nome`, `Endereco`) VALUES ('20230005', 'Mariana Silva', 'Rua E, 202');
INSERT INTO `Universidade`.`Aluno` (`Matricula`, `Nome`, `Endereco`) VALUES ('20230006', 'Roberto Souza', 'Rua F, 303');
INSERT INTO `Universidade`.`Aluno` (`Matricula`, `Nome`, `Endereco`) VALUES ('20230007', 'Juliana Santos', 'Rua G, 404');
INSERT INTO `Universidade`.`Aluno` (`Matricula`, `Nome`, `Endereco`) VALUES ('20230008', 'Felipe Almeida', 'Rua H, 505');
INSERT INTO `Universidade`.`Aluno` (`Matricula`, `Nome`, `Endereco`) VALUES ('20230009', 'Gabriel Lima', 'Rua I, 606');
INSERT INTO `Universidade`.`Aluno` (`Matricula`, `Nome`, `Endereco`) VALUES ('20230010', 'Bob Esponja', 'Rua O, 707');
INSERT INTO `Universidade`.`Aluno` (`Matricula`, `Nome`, `Endereco`) VALUES ('20230011', 'Marcio Silva', 'Rua Z, 808');
INSERT INTO `Universidade`.`Aluno` (`Matricula`, `Nome`, `Endereco`) VALUES ('20230012', 'Rodrigo Painca', 'Rua X, 909');

COMMIT;


-- -----------------------------------------------------
-- Data for table `Universidade`.`Aluno_de_pos_graduacao`
-- -----------------------------------------------------
START TRANSACTION;
USE `Universidade`;
INSERT INTO `Universidade`.`Aluno_de_pos_graduacao` (`Formacao`, `Orientador_Numero`, `Aluno_Matricula`) VALUES (1, 1001, '20230001');
INSERT INTO `Universidade`.`Aluno_de_pos_graduacao` (`Formacao`, `Orientador_Numero`, `Aluno_Matricula`) VALUES (2, 1002, '20230002');
INSERT INTO `Universidade`.`Aluno_de_pos_graduacao` (`Formacao`, `Orientador_Numero`, `Aluno_Matricula`) VALUES (1, 1006, '20230003');
INSERT INTO `Universidade`.`Aluno_de_pos_graduacao` (`Formacao`, `Orientador_Numero`, `Aluno_Matricula`) VALUES (2, 1007, '20230004');
INSERT INTO `Universidade`.`Aluno_de_pos_graduacao` (`Formacao`, `Orientador_Numero`, `Aluno_Matricula`) VALUES (1, 1008, '20230005');
INSERT INTO `Universidade`.`Aluno_de_pos_graduacao` (`Formacao`, `Orientador_Numero`, `Aluno_Matricula`) VALUES (2, 1001, '20230006');
INSERT INTO `Universidade`.`Aluno_de_pos_graduacao` (`Formacao`, `Orientador_Numero`, `Aluno_Matricula`) VALUES (1, 1002, '20230007');
INSERT INTO `Universidade`.`Aluno_de_pos_graduacao` (`Formacao`, `Orientador_Numero`, `Aluno_Matricula`) VALUES (2, 1003, '20230008');
INSERT INTO `Universidade`.`Aluno_de_pos_graduacao` (`Formacao`, `Orientador_Numero`, `Aluno_Matricula`) VALUES (1, 1004, '20230009');
INSERT INTO `Universidade`.`Aluno_de_pos_graduacao` (`Formacao`, `Orientador_Numero`, `Aluno_Matricula`) VALUES (2, 1005, '20230010');
INSERT INTO `Universidade`.`Aluno_de_pos_graduacao` (`Formacao`, `Orientador_Numero`, `Aluno_Matricula`) VALUES (1, 1006, '20230011');
INSERT INTO `Universidade`.`Aluno_de_pos_graduacao` (`Formacao`, `Orientador_Numero`, `Aluno_Matricula`) VALUES (2, 1007, '20230012');

COMMIT;


-- -----------------------------------------------------
-- Data for table `Universidade`.`Aluno_de_Graduacao`
-- -----------------------------------------------------
START TRANSACTION;
USE `Universidade`;
INSERT INTO `Universidade`.`Aluno_de_Graduacao` (`Ano_de_Ingresso`, `Aluno_Matricula`) VALUES ('2021-01-15', '20230001');
INSERT INTO `Universidade`.`Aluno_de_Graduacao` (`Ano_de_Ingresso`, `Aluno_Matricula`) VALUES ('2022-02-20', '20230002');
INSERT INTO `Universidade`.`Aluno_de_Graduacao` (`Ano_de_Ingresso`, `Aluno_Matricula`) VALUES ('2023-03-10', '20230003');
INSERT INTO `Universidade`.`Aluno_de_Graduacao` (`Ano_de_Ingresso`, `Aluno_Matricula`) VALUES ('2020-04-25', '20230004');
INSERT INTO `Universidade`.`Aluno_de_Graduacao` (`Ano_de_Ingresso`, `Aluno_Matricula`) VALUES ('2021-05-30', '20230005');
INSERT INTO `Universidade`.`Aluno_de_Graduacao` (`Ano_de_Ingresso`, `Aluno_Matricula`) VALUES ('2022-07-15', '20230006');
INSERT INTO `Universidade`.`Aluno_de_Graduacao` (`Ano_de_Ingresso`, `Aluno_Matricula`) VALUES ('2022-08-20', '20230007');
INSERT INTO `Universidade`.`Aluno_de_Graduacao` (`Ano_de_Ingresso`, `Aluno_Matricula`) VALUES ('2023-09-25', '20230008');
INSERT INTO `Universidade`.`Aluno_de_Graduacao` (`Ano_de_Ingresso`, `Aluno_Matricula`) VALUES ('2023-10-05', '20230009');
INSERT INTO `Universidade`.`Aluno_de_Graduacao` (`Ano_de_Ingresso`, `Aluno_Matricula`) VALUES ('2024-01-10', '20230010');
INSERT INTO `Universidade`.`Aluno_de_Graduacao` (`Ano_de_Ingresso`, `Aluno_Matricula`) VALUES ('2024-04-20', '20230012');

COMMIT;


-- -----------------------------------------------------
-- Data for table `Universidade`.`Telefone`
-- -----------------------------------------------------
START TRANSACTION;
USE `Universidade`;
INSERT INTO `Universidade`.`Telefone` (`Numero`, `Descricao`, `Aluno_Matricula`) VALUES (123456789, 'Celular', '20230001');
INSERT INTO `Universidade`.`Telefone` (`Numero`, `Descricao`, `Aluno_Matricula`) VALUES (987654321, 'Residencial', '20230002');
INSERT INTO `Universidade`.`Telefone` (`Numero`, `Descricao`, `Aluno_Matricula`) VALUES (112233445, 'Celular', '20230003');
INSERT INTO `Universidade`.`Telefone` (`Numero`, `Descricao`, `Aluno_Matricula`) VALUES (223344556, 'Residencial', '20230004');
INSERT INTO `Universidade`.`Telefone` (`Numero`, `Descricao`, `Aluno_Matricula`) VALUES (334455667, 'Celular', '20230005');
INSERT INTO `Universidade`.`Telefone` (`Numero`, `Descricao`, `Aluno_Matricula`) VALUES (445566778, 'Residencial', '20230006');
INSERT INTO `Universidade`.`Telefone` (`Numero`, `Descricao`, `Aluno_Matricula`) VALUES (556677889, 'Celular', '20230007');
INSERT INTO `Universidade`.`Telefone` (`Numero`, `Descricao`, `Aluno_Matricula`) VALUES (667788990, 'Residencial', '20230008');
INSERT INTO `Universidade`.`Telefone` (`Numero`, `Descricao`, `Aluno_Matricula`) VALUES (778899001, 'Celular', '20230009');
INSERT INTO `Universidade`.`Telefone` (`Numero`, `Descricao`, `Aluno_Matricula`) VALUES (889900112, 'Residencial', '20230010');
INSERT INTO `Universidade`.`Telefone` (`Numero`, `Descricao`, `Aluno_Matricula`) VALUES (990011223, 'Celular', '20230011');
INSERT INTO `Universidade`.`Telefone` (`Numero`, `Descricao`, `Aluno_Matricula`) VALUES (101122334, 'Residencial', '20230012');

COMMIT;


-- -----------------------------------------------------
-- Data for table `Universidade`.`Disciplina_Cursada`
-- -----------------------------------------------------
START TRANSACTION;
USE `Universidade`;
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230001', 1001, 10.0, 81, 'Concluida');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230001', 1004, 7.3, 90, 'Concluida');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230002', 1002, 8.9, 84, 'Concluida');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230002', 1001, 9.2, 64, 'Concluida');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230003', 1002, 8.4, 95, 'Concluida');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230004', 1005, 7.2, 46, 'Concluida');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230005', 1005, 8.2, 68, 'Concluida');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230005', 1006, 7.3, 84, 'Concluida');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230006', 1005, 8.4, 98, 'Concluida');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230006', 1006, 9.1, 43, 'Concluida');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230009', 2003, 9.9, 85, 'Concluida');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230010', 2004, 8.1, 58, 'Concluida');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230012', 2006, 7.2, 70, 'Concluida');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230001', 1003, NULL, NULL, 'Cursando');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230002', 1004, NULL, NULL, 'Cursando');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230003', 1004, NULL, NULL, 'Cursando');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230003', 1003, NULL, NULL, 'Cursando');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230004', 1006, NULL, NULL, 'Cursando');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230004', 1007, NULL, NULL, 'Cursando');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230005', 1007, NULL, NULL, 'Cursando');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230006', 1007, NULL, NULL, 'Cursando');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230007', 2001, NULL, NULL, 'Cursando');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230008', 2002, NULL, NULL, 'Cursando');
INSERT INTO `Universidade`.`Disciplina_Cursada` (`Aluno`, `Disciplina`, `Media_Final`, `Frequenica`, `Status`) VALUES ('20230011', 2005, NULL, NULL, 'Cursando');

COMMIT;


-- -----------------------------------------------------
-- Data for table `Universidade`.`Pre_Requisitos`
-- -----------------------------------------------------
START TRANSACTION;
USE `Universidade`;
INSERT INTO `Universidade`.`Pre_Requisitos` (`Disciplina`, `Pre_Requisito`) VALUES (1002, 1001);
INSERT INTO `Universidade`.`Pre_Requisitos` (`Disciplina`, `Pre_Requisito`) VALUES (1003, 1001);
INSERT INTO `Universidade`.`Pre_Requisitos` (`Disciplina`, `Pre_Requisito`) VALUES (2006, 2007);

COMMIT;

